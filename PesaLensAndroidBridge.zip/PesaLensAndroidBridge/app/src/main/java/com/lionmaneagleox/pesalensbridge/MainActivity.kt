package com.lionmaneagleox.pesalensbridge

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var code: EditText
    private lateinit var baseUrl: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(40, 50, 40, 40)
        }

        val title = TextView(this).apply {
            text = "PesaLens Bridge"
            textSize = 28f
        }
        val info = TextView(this).apply {
            text = "Connect this phone to your PesaLens dashboard. The app reads incoming SMS only to identify M-Pesa transactions and sends structured transaction data to your dashboard. It does not send your M-Pesa PIN or OTP."
            textSize = 16f
            setPadding(0, 20, 0, 30)
        }

        baseUrl = EditText(this).apply {
            hint = "PesaLens URL"
            setText(Prefs.baseUrl(this@MainActivity))
            singleLine = true
        }
        code = EditText(this).apply {
            hint = "Enter 12-character pairing code"
            singleLine = true
        }
        val pair = Button(this).apply {
            text = "PAIR PHONE"
            setOnClickListener { doPair() }
        }
        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 30, 0, 0)
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(baseUrl)
        layout.addView(code)
        layout.addView(pair)
        layout.addView(status)
        setContentView(layout)

        requestSmsPermission()
        status.text = if (Prefs.token(this) != null) "Phone is paired. Waiting for M-Pesa SMS…" else "Enter the pairing code shown on PesaLens."
    }

    private fun requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECEIVE_SMS), 1001)
        }
    }

    private fun doPair() {
        val url = baseUrl.text.toString().trim().trimEnd('/')
        val pairingCode = code.text.toString().trim().uppercase()
        if (url.isBlank() || pairingCode.isBlank()) {
            status.text = "Enter the PesaLens URL and pairing code."
            return
        }

        Prefs.saveBaseUrl(this, url)
        status.text = "Pairing…"

        CoroutineScope(Dispatchers.IO).launch {
            val result = Api.pair(url, pairingCode)
            withContext(Dispatchers.Main) {
                result.onSuccess {
                    Prefs.savePairing(this@MainActivity, it)
                    status.text = "✓ Paired successfully. Leave this app installed; incoming M-Pesa SMS will sync automatically."
                }.onFailure {
                    status.text = "Pairing failed: ${it.message}"
                }
            }
        }
    }
}
