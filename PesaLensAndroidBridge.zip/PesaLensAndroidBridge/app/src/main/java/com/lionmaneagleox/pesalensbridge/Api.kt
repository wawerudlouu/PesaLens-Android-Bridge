package com.lionmaneagleox.pesalensbridge

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

object Api {
    private val client = OkHttpClient()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    fun pair(baseUrl: String, code: String): Result<String> = runCatching {
        val body = JSONObject().put("pairingCode", code).toString().toRequestBody(jsonType)
        val req = Request.Builder().url("$baseUrl/api/bridge/pair").post(body).build()
        client.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) error(JSONObject(text).optString("error", "Pairing failed"))
            val token = JSONObject(text).optString("token")
            if (token.isBlank()) error("No Android token returned")
            token
        }
    }

    fun sendTransaction(baseUrl: String, token: String, tx: MpesaTransaction): Result<String> = runCatching {
        val body = JSONObject()
            .put("token", token)
            .put("transaction_code", tx.code)
            .put("transaction_type", tx.type)
            .put("amount", tx.amount)
            .put("name", tx.name)
            .put("date", tx.date)
            .put("description", tx.description)
            .put("category", tx.category)
            .put("source", "android-sms")
            .toString().toRequestBody(jsonType)

        val req = Request.Builder().url("$baseUrl/api/transactions").post(body).build()
        client.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) error(JSONObject(text).optString("error", "Upload failed"))
            if (JSONObject(text).optBoolean("duplicate", false)) "duplicate"
            else "uploaded"
        }
    }
}
