package com.lionmaneagleox.pesalensbridge

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MpesaTransaction(
    val code: String,
    val type: String,
    val amount: Double,
    val name: String,
    val date: String,
    val description: String,
    val category: String
)

object MpesaParser {
    private val codeRegex = Regex("""\b([A-Z0-9]{10})\b""")
    private val amountRegex = Regex("""(?:Ksh|KES)\s*([\d,]+(?:\.\d{1,2})?)""", RegexOption.IGNORE_CASE)

    fun parse(body: String, timestamp: Long = System.currentTimeMillis()): MpesaTransaction? {
        val text = body.replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        val lower = text.lowercase()

        val code = codeRegex.find(text)?.groupValues?.get(1) ?: return null
        val amount = amountRegex.find(text)?.groupValues?.get(1)
            ?.replace(",", "")?.toDoubleOrNull() ?: return null

        val isIn = listOf("received", "from", "credited", "you have received", "deposit").any { lower.contains(it) }
        val isOut = listOf("sent to", "paid to", "payment of", "withdraw", "withdrawn", "you have sent").any { lower.contains(it) }
        if (!isIn && !isOut) return null

        val type = if (isIn) "Money In" else "Money Out"
        val name = extractName(text, isIn)
        val category = if (isIn) "Other" else inferExpenseCategory(lower)

        val isoDate = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
            .format(Date(timestamp))

        return MpesaTransaction(
            code = code,
            type = type,
            amount = amount,
            name = name,
            date = isoDate,
            description = "M-Pesa SMS",
            category = category
        )
    }

    private fun extractName(text: String, isIn: Boolean): String {
        val pattern = if (isIn)
            Regex("""(?:from|received from)\s+([A-Za-z][A-Za-z .'-]{2,60}?)(?:\s+on|\s+has|\s+at|\.|$)""", RegexOption.IGNORE_CASE)
        else
            Regex("""(?:to|paid to)\s+([A-Za-z][A-Za-z .'-]{2,60}?)(?:\s+on|\s+for|\s+at|\.|$)""", RegexOption.IGNORE_CASE)
        return pattern.find(text)?.groupValues?.get(1)?.trim() ?: "Unknown"
    }

    private fun inferExpenseCategory(text: String): String = when {
        listOf("fuel", "petrol", "shell", "total").any { text.contains(it) } -> "Fuel"
        listOf("rent", "landlord").any { text.contains(it) } -> "Rent"
        listOf("electricity", "water", "token", "bill").any { text.contains(it) } -> "Bills"
        listOf("food", "restaurant", "hotel", "cafe").any { text.contains(it) } -> "Food"
        listOf("fare", "transport", "matatu", "uber").any { text.contains(it) } -> "Transport"
        else -> "Other"
    }
}
