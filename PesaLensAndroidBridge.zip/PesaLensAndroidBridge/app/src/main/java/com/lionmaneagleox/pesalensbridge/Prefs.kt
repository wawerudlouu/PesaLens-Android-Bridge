package com.lionmaneagleox.pesalensbridge

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object Prefs {
    private const val FILE = "pesalens_secure"
    private const val TOKEN = "android_token"
    private const val BASE_URL = "base_url"

    private fun prefs(context: Context) =
        EncryptedSharedPreferences.create(
            context,
            FILE,
            MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

    fun token(context: Context): String? = prefs(context).getString(TOKEN, null)
    fun baseUrl(context: Context): String =
        prefs(context).getString(BASE_URL, "https://9a2d56325639892813.v2.appdeploy.ai")!!

    fun savePairing(context: Context, token: String) =
        prefs(context).edit().putString(TOKEN, token).apply()

    fun saveBaseUrl(context: Context, url: String) =
        prefs(context).edit().putString(BASE_URL, url.trim().trimEnd('/')).apply()
}
