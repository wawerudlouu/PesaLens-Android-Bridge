package com.lionmaneagleox.pesalensbridge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val pending = goAsync()
        val appContext = context.applicationContext

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val token = Prefs.token(appContext) ?: return@launch
                val baseUrl = Prefs.baseUrl(appContext)
                val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)

                val grouped = messages.groupBy { it.displayOriginatingAddress ?: "unknown" }
                for ((_, parts) in grouped) {
                    val body = parts.joinToString("") { it.displayMessageBody ?: "" }
                    val tx = MpesaParser.parse(body, parts.firstOrNull()?.timestampMillis ?: System.currentTimeMillis())
                    if (tx != null) Api.sendTransaction(baseUrl, token, tx)
                }
            } finally {
                pending.finish()
            }
        }
    }
}
